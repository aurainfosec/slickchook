# Slickchook roadmap

Updated: 2026-07-15

## Attack-surface orchestration

- [ ] Add a workflow/DAG runner for staged reconnaissance.
- [ ] Parallelize independent passive discovery plugins.
- [ ] Deduplicate domains, IPs, ports, URLs, and findings between stages.
- [ ] Feed discovered assets automatically into DNS, port, HTTP, and service probes.
- [ ] Crawl only confirmed HTTP(S) services.
- [ ] Prioritize API, OpenAPI/Swagger, GraphQL, login, admin, and JavaScript surfaces.
- [ ] Add authenticated testing using short-lived, redacted credentials or API keys.
- [ ] Add per-host concurrency and rate-limit budgets.
- [ ] Stop or back off after repeated timeouts, 429s, or 503s.
- [ ] Cache DNS, HTTP, certificate, and technology results with timestamps.
- [ ] Track plugin/image versions, digests, options, target, and provenance.
- [ ] Emit a normalized attack-surface inventory alongside raw artifacts.
- [ ] Support incremental rescans based on changed assets.
- [ ] Add scheduled monitoring and change detection.

## Plugin quality and safety

- [ ] Verify image availability and CLI compatibility during plugin installation.
- [ ] Add plugin smoke tests for image entrypoints and required files.
- [ ] Redact secrets from inputs, logs, database records, and artifacts.
- [ ] Preserve least privilege for the MCP service and runner.
