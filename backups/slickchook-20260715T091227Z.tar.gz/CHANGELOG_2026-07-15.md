# Changelog — 2026-07-15

## Perimeter enumeration runtime fixes

- Added a constrained writable `/tmp` tmpfs to HTTPX after live testing found
  its resolver cache could not be created on the read-only container root.
- Fixed the Feroxbuster image Dockerfile to create `/opt/slickchook` before
  copying its bounded package wordlist. Full SecLists content remains opt-in
  rather than being embedded in privileged images.
- Made the Feroxbuster image build assert that its wordlist exists and moved
  the file to `/wordlist.txt` to avoid ambiguous nested-directory COPY behavior.
- Hardened stdout/stderr artifact recording against symlink or non-regular-file
  interference and improved write error reporting.

## Fixed

- Enabled the MCP tools capability in the server's initialization response.
- Attached `#[tool_router]` to the implementation that defines `run_plugin`,
  `list_plugins`, and `health`, so those tools are registered with the router.
- Attached `#[tool_handler]` to the `ServerHandler` implementation, so
  `tools/list` and `tools/call` requests are dispatched through that router
  instead of falling back to rmcp's default handlers.
- Declared the `run_plugin` arguments as an rmcp `Parameters` schema so the
  router accepts the existing `{ "plugin": ..., "input": ... }` MCP payload.
- Added an idempotent Ubuntu installation script and systemd unit template that
  install the runner as `root:docker` with mode `2750`, grant only the service
  account execution via ACL, configure artifact ACL inheritance, and verify the
  resulting deployment.
- Extended the installer to recognize existing deployments, preserve runtime
  data, back up files changed by an update, normalize legacy accounts and Docker
  group membership, stop managed services safely, and reject unmanaged port
  conflicts.
- Added containerized plugins for Nmap TCP connect scanning, ProjectDiscovery
  Naabu CONNECT scanning, and a focused `rawping` check that requests only the
  `NET_RAW` capability.
- Fixed Docker bind mounts by passing the runner's validated canonical artifact
  directory instead of a relative path that Docker treated as a volume name.
- Added pinned ProjectDiscovery Nuclei and HTTPX plugins with bounded resources,
  update checks disabled, and no additional Linux capabilities.
- Decoupled plugin deployment from core installation. The core installer now
  installs a standalone `slickchook-plugin` manager, while independent plugin
  packages can be installed, updated, validated, rolled back, listed, and
  removed without access to the core or runner source repositories.
- Added independently buildable packages for Medusa single-credential checks,
  bounded Feroxbuster content discovery, and Waymore archive enumeration, plus
  a pinned official Subfinder plugin for passive bug-bounty enumeration.
- Extended `slickchook-plugin` to build package-owned Dockerfiles with local
  image tagging and rollback tags, avoiding unreviewed third-party tool images.

## Tests

- Added checks that the server advertises tool support and registers all three
  MCP tools.
- Verified the rebuilt server over its SSE transport: initialization advertised
  `tools`, `tools/list` returned all three tools, and `tools/call` successfully
  invoked `health`.
- Added manifest-loading checks for the Nmap, Naabu, and rawping plugins and
  their intended capability policies.
- Extended manifest checks to cover the pinned Nuclei and HTTPX images.
## Plugin runtime filesystem fixes

- Added writable, constrained `/tmp` tmpfs to the Naabu profile, fixing its
  `Could not create runner: mkdir /tmp/...: read-only file system` failure.
- Added constrained `/.config` tmpfs mounts to Subfinder and Nuclei, whose
  non-root runtime defaults otherwise attempt to create configuration under
  the read-only container root.
- The Feroxbuster package includes its wordlist in the image; reinstalling the
  package rebuilds the image so older deployments receive that file.
## Perimeter enumeration plugins

- Added independently installable `dnsx`, `katana`, and `gowitness` plugin
  packages for DNS verification, bounded web crawling, and visual web triage.
- Pinned dnsx and Katana image tags; all three profiles use non-root containers,
  resource limits, and constrained writable temporary filesystems.
