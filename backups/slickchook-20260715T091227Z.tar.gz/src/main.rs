use anyhow::Result;
use rmcp::{
    ServerHandler,
    handler::server::tool::{Parameters, ToolRouter},
    model::*,
    schemars, tool, tool_handler, tool_router,
    transport::sse_server::SseServer,
};
use serde::Deserialize;
use slickchook::plugin_manager::PluginManager;
use std::sync::Arc;

#[derive(Debug, Deserialize, schemars::JsonSchema)]
struct RunPluginRequest {
    plugin: String,
    input: serde_json::Value,
}

#[derive(Clone)]
#[allow(dead_code)]
struct ReconServer {
    tool_router: ToolRouter<Self>,
    plugin_manager: Arc<PluginManager>,
}

impl ReconServer {
    fn new(plugin_manager: Arc<PluginManager>) -> Self {
        Self {
            tool_router: Self::tool_router(),
            plugin_manager,
        }
    }
}

#[tool_router]
impl ReconServer {
    #[tool(description = "Run a recon plugin by name using JSON input")]
    async fn run_plugin(
        &self,
        Parameters(RunPluginRequest { plugin, input }): Parameters<RunPluginRequest>,
    ) -> Result<String, rmcp::ErrorData> {
        let result = self
            .plugin_manager
            .run_plugin(&plugin, input)
            .await
            .map_err(|error| rmcp::ErrorData::internal_error(error.to_string(), None))?;
        serde_json::to_string_pretty(&result)
            .map_err(|error| rmcp::ErrorData::internal_error(error.to_string(), None))
    }

    #[tool(description = "List available recon plugins and their declared inputs")]
    async fn list_plugins(&self) -> Result<String, rmcp::ErrorData> {
        let plugins = self
            .plugin_manager
            .list_plugins()
            .map_err(|error| rmcp::ErrorData::internal_error(error.to_string(), None))?;
        serde_json::to_string_pretty(&plugins)
            .map_err(|error| rmcp::ErrorData::internal_error(error.to_string(), None))
    }

    #[tool(description = "Basic health check")]
    async fn health(&self) -> Result<String, rmcp::ErrorData> {
        Ok("recon-mcp is running".to_string())
    }
}

#[tool_handler]
impl ServerHandler for ReconServer {
    fn get_info(&self) -> ServerInfo {
        server_info()
    }
}

fn server_info() -> ServerInfo {
    ServerInfo {
        capabilities: ServerCapabilities::builder().enable_tools().build(),
        instructions: Some(
            "HTTP MCP server for running recon plugins via JSON input/output.".into(),
        ),
        ..Default::default()
    }
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    tracing_subscriber::fmt::init();

    let bind_addr = "127.0.0.1:8080";
    let plugin_manager = Arc::new(PluginManager::new(
        "plugins",
        "artifacts",
        "artifacts/plugin_runs.sqlite3",
    )?);

    let service_plugin_manager = Arc::clone(&plugin_manager);
    let _ct = SseServer::serve(bind_addr.parse()?)
        .await?
        .with_service(move || ReconServer::new(Arc::clone(&service_plugin_manager)));

    println!("MCP SSE server running at http://{}/sse", bind_addr);
    println!("Press Ctrl+C to stop.");

    tokio::signal::ctrl_c().await?;

    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn advertises_tool_capability() {
        assert!(server_info().capabilities.tools.is_some());
    }

    #[test]
    fn registers_all_mcp_tools() {
        let router = ReconServer::tool_router();

        assert!(router.has_route("run_plugin"));
        assert!(router.has_route("list_plugins"));
        assert!(router.has_route("health"));
        assert_eq!(router.list_all().len(), 3);
    }
}
