use anyhow::{Context, Result, anyhow, bail};
use chrono::Utc;
use rusqlite::{Connection, params};
use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::{
    collections::{HashMap, HashSet},
    env,
    ffi::OsStr,
    fs,
    path::{Path, PathBuf},
    process::Stdio,
    sync::{Arc, RwLock},
    time::Duration,
};
use tokio::{process::Command, time};
use tracing::warn;
use uuid::Uuid;

const DEFAULT_TIMEOUT_SECONDS: u64 = 300;

#[derive(Clone)]
pub struct PluginManager {
    plugins_dir: PathBuf,
    artifacts_dir: PathBuf,
    db_path: PathBuf,
    runner_path: PathBuf,
    plugins: Arc<RwLock<HashMap<String, Plugin>>>,
}

#[derive(Clone, Debug)]
#[allow(dead_code)]
pub struct Plugin {
    pub manifest_path: PathBuf,
    pub manifest: PluginManifest,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
#[allow(dead_code)]
pub struct PluginManifest {
    pub name: String,
    pub container: String,
    pub description: String,
    #[serde(default)]
    pub fixed_args: Vec<String>,
    #[serde(default)]
    pub options: Vec<PluginOption>,
    #[serde(default)]
    pub arguments: Vec<PluginArgument>,
    #[serde(default)]
    pub docker: DockerPolicy,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct PluginOption {
    pub name: String,
    pub description: String,
    #[serde(default)]
    pub required: bool,
    #[serde(default)]
    pub flag: Option<String>,
    #[serde(default)]
    pub default: Option<Value>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct PluginArgument {
    pub name: String,
    pub description: String,
    #[serde(default)]
    pub required: bool,
    #[serde(default)]
    pub position: Option<u32>,
    #[serde(default)]
    pub default: Option<Value>,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
#[allow(dead_code)]
pub struct DockerPolicy {
    #[serde(default = "default_network")]
    pub network: String,
    #[serde(default = "default_memory")]
    pub memory: String,
    #[serde(default = "default_cpus")]
    pub cpus: String,
    #[serde(default = "default_pids_limit")]
    pub pids_limit: u32,
    #[serde(default = "default_timeout_seconds")]
    pub timeout_seconds: u64,
    #[serde(default)]
    pub tmpfs: Vec<String>,
    #[serde(default)]
    pub cap_add: Vec<String>,
    #[serde(default = "default_input_read_only")]
    pub input_read_only: bool,
}

fn default_input_read_only() -> bool {
    true
}

impl Default for DockerPolicy {
    fn default() -> Self {
        Self {
            network: default_network(),
            memory: default_memory(),
            cpus: default_cpus(),
            pids_limit: default_pids_limit(),
            timeout_seconds: default_timeout_seconds(),
            tmpfs: Vec::new(),
            cap_add: Vec::new(),
            input_read_only: true,
        }
    }
}

#[derive(Clone, Debug, Serialize)]
#[allow(dead_code)]
pub struct PluginInfo {
    pub name: String,
    pub container: String,
    pub description: String,
    pub fixed_args: Vec<String>,
    pub docker: DockerPolicy,
    pub options: Vec<PluginOption>,
    pub arguments: Vec<PluginArgument>,
}

#[derive(Debug, Serialize)]
#[allow(dead_code)]
pub struct PluginRunResult {
    pub run_id: String,
    pub plugin: String,
    pub status: String,
    pub exit_code: Option<i32>,
    pub artifact_dir: String,
    pub stdout_artifact: String,
    pub stderr_artifact: String,
    pub artifacts: Vec<String>,
    pub stdout_preview: String,
    pub stderr_preview: String,
}

#[allow(dead_code)]
impl PluginManager {
    /// Resolve a completed run's staged input directory without accepting an
    /// arbitrary filesystem path from an MCP caller.
    pub fn resolve_input_run(&self, run_id: &str) -> Result<PathBuf> {
        let conn = Connection::open(&self.db_path)
            .with_context(|| format!("failed to open {}", self.db_path.display()))?;
        let artifact_dir: String = conn
            .query_row(
                "SELECT artifact_dir FROM plugin_runs WHERE run_id = ?1 AND status IN ('success','failed')",
                params![run_id],
                |row| row.get(0),
            )
            .with_context(|| format!("run `{run_id}` is unknown or not complete"))?;
        let root = fs::canonicalize(&self.artifacts_dir)?;
        let artifact_path = PathBuf::from(&artifact_dir);
        let artifact_path = if artifact_path.is_absolute() {
            artifact_path
        } else {
            fs::canonicalize(&artifact_path)?
        };
        let run_dir = fs::canonicalize(&artifact_path)?;
        if !run_dir.starts_with(&root) {
            bail!("run artifact is outside artifact root");
        }
        let input_dir = run_dir.join("input");
        let input_dir = fs::canonicalize(&input_dir)
            .with_context(|| format!("run `{run_id}` has no input staging directory"))?;
        if !input_dir.starts_with(&run_dir) {
            bail!("input staging directory escapes run directory");
        }
        Ok(input_dir)
    }
    pub fn new(
        plugins_dir: impl Into<PathBuf>,
        artifacts_dir: impl Into<PathBuf>,
        db_path: impl Into<PathBuf>,
    ) -> Result<Self> {
        let manager = Self {
            plugins_dir: plugins_dir.into(),
            artifacts_dir: artifacts_dir.into(),
            db_path: db_path.into(),
            runner_path: runner_path(),
            plugins: Arc::new(RwLock::new(HashMap::new())),
        };

        fs::create_dir_all(&manager.plugins_dir)
            .with_context(|| format!("failed to create {}", manager.plugins_dir.display()))?;
        fs::create_dir_all(&manager.artifacts_dir)
            .with_context(|| format!("failed to create {}", manager.artifacts_dir.display()))?;
        manager.init_db()?;
        manager.reload()?;

        Ok(manager)
    }

    pub fn reload(&self) -> Result<()> {
        let plugins = scan_plugins(&self.plugins_dir)?;
        let mut guard = self
            .plugins
            .write()
            .map_err(|_| anyhow!("plugin registry lock is poisoned"))?;
        *guard = plugins;
        Ok(())
    }

    pub fn list_plugins(&self) -> Result<Vec<PluginInfo>> {
        let guard = self
            .plugins
            .read()
            .map_err(|_| anyhow!("plugin registry lock is poisoned"))?;
        let mut plugins: Vec<_> = guard
            .values()
            .map(|plugin| PluginInfo {
                name: plugin.manifest.name.clone(),
                container: plugin.manifest.container.clone(),
                description: plugin.manifest.description.clone(),
                fixed_args: plugin.manifest.fixed_args.clone(),
                docker: plugin.manifest.docker.clone(),
                options: plugin.manifest.options.clone(),
                arguments: plugin.manifest.arguments.clone(),
            })
            .collect();
        plugins.sort_by(|left, right| left.name.cmp(&right.name));
        Ok(plugins)
    }

    pub async fn run_plugin(&self, plugin_name: &str, input: Value) -> Result<PluginRunResult> {
        self.run_plugin_with_input(plugin_name, input, None).await
    }

    pub async fn run_plugin_with_input(
        &self,
        plugin_name: &str,
        input: Value,
        input_run_id: Option<&str>,
    ) -> Result<PluginRunResult> {
        let plugin = self.plugin(plugin_name)?;
        let run_id = Uuid::new_v4().to_string();
        let started_at = Utc::now().to_rfc3339();
        let artifact_dir = self.artifacts_dir.join(&run_id);
        fs::create_dir_all(&artifact_dir)
            .with_context(|| format!("failed to create {}", artifact_dir.display()))?;
        let artifact_dir = fs::canonicalize(&artifact_dir)
            .with_context(|| format!("failed to canonicalize {}", artifact_dir.display()))?;
        fs::create_dir_all(artifact_dir.join("input")).with_context(|| {
            format!(
                "failed to create input staging directory in {}",
                artifact_dir.display()
            )
        })?;

        let input_dir = input_run_id
            .map(|id| self.resolve_input_run(id))
            .transpose()?;
        let output = self
            .run_runner(&plugin, &artifact_dir, &input, input_dir.as_deref())
            .await;
        let finished_at = Utc::now().to_rfc3339();

        let stdout_path = artifact_dir.join("stdout.txt");
        let stderr_path = artifact_dir.join("stderr.txt");

        let (status, exit_code, stdout, stderr) = match output {
            Ok(output) => {
                let status = if output.status.success() {
                    "success".to_string()
                } else {
                    "failed".to_string()
                };
                (status, output.status.code(), output.stdout, output.stderr)
            }
            Err(error) => (
                "error".to_string(),
                None,
                Vec::new(),
                error.to_string().into_bytes(),
            ),
        };

        // Preserve the runner's original diagnostics in the service journal. This is
        // especially useful when a container exits before artifact persistence (for
        // example, a Docker bind-mount or permission failure).
        if status != "success" || !stderr.is_empty() {
            let metadata = fs::metadata(&artifact_dir).ok();
            warn!(
                plugin = %plugin_name,
                status = %status,
                exit_code = ?exit_code,
                artifact_dir = %artifact_dir.display(),
                artifact_mode = ?metadata.as_ref().map(|m| m.permissions()),
                runner_stdout = %output_preview(&stdout),
                runner_stderr = %output_preview(&stderr),
                "plugin runner produced diagnostics"
            );
        }

        write_artifact(&stdout_path, &stdout)?;
        write_artifact(&stderr_path, &stderr)?;
        let artifacts = list_artifacts(&artifact_dir)?;
        let stdout_preview = output_preview(&stdout);
        let stderr_preview = output_preview(&stderr);

        self.record_run(RunRecord {
            run_id: &run_id,
            plugin_name,
            container: &plugin.manifest.container,
            input: &input.to_string(),
            status: &status,
            exit_code,
            artifact_dir: &artifact_dir.to_string_lossy(),
            stdout_path: &stdout_path.to_string_lossy(),
            stderr_path: &stderr_path.to_string_lossy(),
            started_at: &started_at,
            finished_at: &finished_at,
        })?;

        Ok(PluginRunResult {
            run_id,
            plugin: plugin_name.to_string(),
            status,
            exit_code,
            artifact_dir: artifact_dir.to_string_lossy().into_owned(),
            stdout_artifact: stdout_path.to_string_lossy().into_owned(),
            stderr_artifact: stderr_path.to_string_lossy().into_owned(),
            artifacts,
            stdout_preview,
            stderr_preview,
        })
    }

    fn plugin(&self, plugin_name: &str) -> Result<Plugin> {
        let guard = self
            .plugins
            .read()
            .map_err(|_| anyhow!("plugin registry lock is poisoned"))?;
        guard
            .get(plugin_name)
            .cloned()
            .ok_or_else(|| anyhow!("unknown plugin `{plugin_name}`"))
    }

    async fn run_runner(
        &self,
        plugin: &Plugin,
        artifact_dir: &Path,
        input: &Value,
        input_dir: Option<&Path>,
    ) -> Result<std::process::Output> {
        let input_json =
            serde_json::to_string(input).context("failed to serialize plugin input")?;
        let mut command = Command::new(&self.runner_path);
        command
            .arg("--manifest")
            .arg(&plugin.manifest_path)
            .arg("--plugins-root")
            .arg(&self.plugins_dir)
            .arg("--artifact-dir")
            .arg(artifact_dir)
            .arg("--input-dir")
            .arg(input_dir.unwrap_or(&artifact_dir.join("input")))
            .arg("--artifacts-root")
            .arg(&self.artifacts_dir)
            .arg("--input-json")
            .arg(input_json)
            .stdin(Stdio::null())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped());

        let timeout = Duration::from_secs(plugin.manifest.docker.timeout_seconds + 30);
        time::timeout(timeout, command.output())
            .await
            .with_context(|| {
                format!(
                    "plugin runner for `{}` exceeded timeout of {} seconds",
                    plugin.manifest.name,
                    plugin.manifest.docker.timeout_seconds + 30
                )
            })?
            .with_context(|| format!("failed to run {}", self.runner_path.display()))
    }

    fn init_db(&self) -> Result<()> {
        let conn = Connection::open(&self.db_path)
            .with_context(|| format!("failed to open {}", self.db_path.display()))?;
        conn.execute_batch(
            "CREATE TABLE IF NOT EXISTS plugin_runs (
                run_id TEXT PRIMARY KEY,
                plugin_name TEXT NOT NULL,
                container TEXT NOT NULL,
                input_json TEXT NOT NULL,
                status TEXT NOT NULL,
                exit_code INTEGER,
                artifact_dir TEXT NOT NULL,
                stdout_path TEXT NOT NULL,
                stderr_path TEXT NOT NULL,
                started_at TEXT NOT NULL,
                finished_at TEXT NOT NULL
            );",
        )
        .context("failed to initialize plugin run database")?;
        Ok(())
    }

    fn record_run(&self, record: RunRecord<'_>) -> Result<()> {
        let conn = Connection::open(&self.db_path)
            .with_context(|| format!("failed to open {}", self.db_path.display()))?;
        conn.execute(
            "INSERT INTO plugin_runs (
                run_id, plugin_name, container, input_json, status, exit_code,
                artifact_dir, stdout_path, stderr_path, started_at, finished_at
            ) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11)",
            params![
                record.run_id,
                record.plugin_name,
                record.container,
                record.input,
                record.status,
                record.exit_code,
                record.artifact_dir,
                record.stdout_path,
                record.stderr_path,
                record.started_at,
                record.finished_at,
            ],
        )
        .context("failed to record plugin run")?;
        Ok(())
    }
}

#[allow(dead_code)]
struct RunRecord<'a> {
    run_id: &'a str,
    plugin_name: &'a str,
    container: &'a str,
    input: &'a str,
    status: &'a str,
    exit_code: Option<i32>,
    artifact_dir: &'a str,
    stdout_path: &'a str,
    stderr_path: &'a str,
    started_at: &'a str,
    finished_at: &'a str,
}

fn scan_plugins(plugins_dir: &Path) -> Result<HashMap<String, Plugin>> {
    let mut plugins = HashMap::new();

    for entry in fs::read_dir(plugins_dir)
        .with_context(|| format!("failed to read {}", plugins_dir.display()))?
    {
        let entry = entry?;
        if !entry.file_type()?.is_dir() {
            continue;
        }

        for manifest_path in plugin_manifests(&entry.path())? {
            let manifest = load_manifest(&manifest_path)?;
            if plugins.contains_key(&manifest.name) {
                bail!("duplicate plugin name `{}`", manifest.name);
            }

            plugins.insert(
                manifest.name.clone(),
                Plugin {
                    manifest_path,
                    manifest,
                },
            );
        }
    }

    Ok(plugins)
}

fn plugin_manifests(plugin_dir: &Path) -> Result<Vec<PathBuf>> {
    let mut manifests = Vec::new();
    for entry in fs::read_dir(plugin_dir)
        .with_context(|| format!("failed to read {}", plugin_dir.display()))?
    {
        let entry = entry?;
        let path = entry.path();
        if entry.file_type()?.is_file() && path.extension() == Some(OsStr::new("toml")) {
            manifests.push(path);
        }
    }
    manifests.sort();
    Ok(manifests)
}

pub fn load_manifest(path: &Path) -> Result<PluginManifest> {
    let raw = fs::read_to_string(path)
        .with_context(|| format!("failed to read plugin manifest {}", path.display()))?;
    let manifest: PluginManifest = toml::from_str(&raw)
        .with_context(|| format!("failed to parse plugin manifest {}", path.display()))?;
    validate_manifest(&manifest).with_context(|| format!("invalid manifest {}", path.display()))?;
    Ok(manifest)
}

fn validate_manifest(manifest: &PluginManifest) -> Result<()> {
    validate_key(&manifest.name, "plugin name")?;
    validate_container_name(&manifest.container)?;
    validate_docker_policy(&manifest.docker)?;
    for arg in &manifest.fixed_args {
        validate_fixed_arg(arg)?;
    }

    let mut names = HashSet::new();
    for option in &manifest.options {
        validate_key(&option.name, "option name")?;
        if !names.insert(format!("option:{}", option.name)) {
            bail!("duplicate option `{}`", option.name);
        }
    }

    for argument in &manifest.arguments {
        validate_key(&argument.name, "argument name")?;
        if !names.insert(format!("argument:{}", argument.name)) {
            bail!("duplicate argument `{}`", argument.name);
        }
    }

    Ok(())
}

fn validate_key(value: &str, label: &str) -> Result<()> {
    if value.is_empty()
        || !value
            .chars()
            .all(|ch| ch.is_ascii_alphanumeric() || ch == '_' || ch == '-')
    {
        bail!("{label} must contain only ASCII letters, numbers, dashes, or underscores");
    }
    Ok(())
}

fn validate_container_name(container: &str) -> Result<()> {
    if container.is_empty()
        || container.starts_with('-')
        || !container
            .chars()
            .all(|ch| ch.is_ascii_alphanumeric() || ".:/_-@".contains(ch))
    {
        bail!("container image name contains unsupported characters");
    }
    Ok(())
}

pub fn validate_docker_policy(policy: &DockerPolicy) -> Result<()> {
    if !matches!(policy.network.as_str(), "none" | "bridge") {
        bail!("docker network must be `none` or `bridge`");
    }
    if policy.pids_limit == 0 {
        bail!("pids_limit must be greater than zero");
    }
    if policy.timeout_seconds == 0 {
        bail!("timeout_seconds must be greater than zero");
    }
    for tmpfs in &policy.tmpfs {
        validate_tmpfs(tmpfs)?;
    }
    for cap in &policy.cap_add {
        validate_cap_add(cap)?;
    }
    Ok(())
}

#[allow(dead_code)]
pub fn build_container_args(manifest: &PluginManifest, input: &Value) -> Result<Vec<String>> {
    let input = input
        .as_object()
        .ok_or_else(|| anyhow!("plugin input must be a JSON object"))?;
    let mut args = manifest.fixed_args.clone();
    let mut allowed = HashSet::new();

    for option in &manifest.options {
        allowed.insert(option.name.as_str());
        let value = input.get(&option.name).or(option.default.as_ref());
        match value {
            Some(Value::Bool(false)) | None if !option.required => continue,
            None => bail!("missing required option `{}`", option.name),
            Some(value) => {
                if let Some(flag) = &option.flag {
                    args.push(flag.clone());
                }
                if !matches!(value, Value::Bool(true)) {
                    args.push(json_value_to_arg(value)?);
                }
            }
        }
    }

    let mut positional = manifest.arguments.clone();
    positional.sort_by_key(|argument| argument.position.unwrap_or(u32::MAX));
    for argument in &positional {
        allowed.insert(argument.name.as_str());
        let value = input.get(&argument.name).or(argument.default.as_ref());
        match value {
            None if !argument.required => continue,
            None => bail!("missing required argument `{}`", argument.name),
            Some(value) => args.push(json_value_to_arg(value)?),
        }
    }

    for key in input.keys() {
        if !allowed.contains(key.as_str()) {
            bail!(
                "input key `{key}` is not declared by plugin `{}`",
                manifest.name
            );
        }
    }

    Ok(args)
}

#[allow(dead_code)]
fn json_value_to_arg(value: &Value) -> Result<String> {
    match value {
        Value::String(value) => validate_user_arg(value),
        Value::Number(value) => Ok(value.to_string()),
        Value::Bool(value) => Ok(value.to_string()),
        Value::Null => bail!("null values are not valid plugin arguments"),
        Value::Array(_) | Value::Object(_) => {
            bail!("array and object values are not valid plugin arguments")
        }
    }
}

fn validate_fixed_arg(value: &str) -> Result<()> {
    if value.is_empty() || value.contains('\0') {
        bail!("fixed arguments must be non-empty strings without NUL bytes");
    }
    Ok(())
}

fn validate_tmpfs(value: &str) -> Result<()> {
    if value.is_empty()
        || value.starts_with('-')
        || value.contains('\0')
        || !value
            .chars()
            .all(|ch| ch.is_ascii_alphanumeric() || "/:,.=_-".contains(ch))
    {
        bail!("tmpfs entries contain unsupported characters");
    }
    Ok(())
}

fn validate_cap_add(value: &str) -> Result<()> {
    if value != "NET_RAW" {
        bail!("cap_add only supports `NET_RAW`");
    }
    Ok(())
}

fn validate_user_arg(value: &str) -> Result<String> {
    if value.is_empty() || value.contains('\0') || value.starts_with('-') {
        bail!(
            "string arguments must be non-empty, must not start with '-', and must not contain NUL bytes"
        );
    }
    Ok(value.to_string())
}

fn output_preview(bytes: &[u8]) -> String {
    const PREVIEW_LIMIT: usize = 64 * 1024;
    let preview_len = bytes.len().min(PREVIEW_LIMIT);
    let mut preview = String::from_utf8_lossy(&bytes[..preview_len]).into_owned();
    if bytes.len() > PREVIEW_LIMIT {
        preview.push_str("\n[output truncated; full output is available in artifacts]");
    }
    preview
}

fn write_artifact(path: &Path, bytes: &[u8]) -> Result<()> {
    if path.exists() {
        let metadata = fs::symlink_metadata(path)
            .with_context(|| format!("failed to inspect artifact {}", path.display()))?;
        if metadata.file_type().is_symlink() || !metadata.file_type().is_file() {
            bail!(
                "refusing to overwrite non-regular artifact {}",
                path.display()
            );
        }
    }

    let mut file = fs::OpenOptions::new()
        .create(true)
        .truncate(true)
        .write(true)
        .open(path)
        .with_context(|| format!("failed to open artifact {}", path.display()))?;
    use std::io::Write as _;
    file.write_all(bytes)
        .with_context(|| format!("failed to write artifact {}", path.display()))?;
    Ok(())
}

fn list_artifacts(artifact_dir: &Path) -> Result<Vec<String>> {
    let mut artifacts = Vec::new();
    for entry in fs::read_dir(artifact_dir)
        .with_context(|| format!("failed to read {}", artifact_dir.display()))?
    {
        let entry = entry?;
        if entry.file_type()?.is_file() {
            artifacts.push(entry.path().to_string_lossy().into_owned());
        }
    }
    artifacts.sort();
    Ok(artifacts)
}

fn runner_path() -> PathBuf {
    if let Ok(path) = env::var("SLICKCHOOK_RUNNER") {
        return PathBuf::from(path);
    }

    env::current_exe()
        .ok()
        .and_then(|path| path.parent().map(|parent| parent.join("slickchook-runner")))
        .unwrap_or_else(|| PathBuf::from("slickchook-runner"))
}

fn default_network() -> String {
    "none".to_string()
}

fn default_memory() -> String {
    "512m".to_string()
}

fn default_cpus() -> String {
    "1".to_string()
}

fn default_pids_limit() -> u32 {
    128
}

fn default_timeout_seconds() -> u64 {
    DEFAULT_TIMEOUT_SECONDS
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn builds_args_from_declared_options_and_arguments() {
        let manifest = PluginManifest {
            name: "probe".to_string(),
            container: "tool:latest".to_string(),
            description: "test".to_string(),
            fixed_args: vec![
                "--jsonfile".to_string(),
                "/artifacts/result.json".to_string(),
            ],
            options: vec![PluginOption {
                name: "verbose".to_string(),
                description: "verbose output".to_string(),
                required: false,
                flag: Some("--verbose".to_string()),
                default: None,
            }],
            arguments: vec![PluginArgument {
                name: "target".to_string(),
                description: "target host".to_string(),
                required: true,
                position: Some(1),
                default: None,
            }],
            docker: DockerPolicy::default(),
        };

        let input = serde_json::json!({
            "verbose": true,
            "target": "example.com"
        });

        let args = build_container_args(&manifest, &input).unwrap();
        assert_eq!(
            args,
            vec![
                "--jsonfile",
                "/artifacts/result.json",
                "--verbose",
                "example.com"
            ]
        );
    }

    #[test]
    fn rejects_undeclared_input() {
        let manifest = PluginManifest {
            name: "probe".to_string(),
            container: "tool:latest".to_string(),
            description: "test".to_string(),
            fixed_args: Vec::new(),
            options: Vec::new(),
            arguments: Vec::new(),
            docker: DockerPolicy::default(),
        };

        let input = serde_json::json!({ "unexpected": "value" });
        let error = build_container_args(&manifest, &input).unwrap_err();
        assert!(error.to_string().contains("not declared"));
    }

    #[test]
    fn scans_testssl_plugin_manifest() {
        let plugins = scan_plugins(Path::new("plugins")).unwrap();
        let plugin = plugins.get("testssl").unwrap();

        assert_eq!(plugin.manifest.container, "drwetter/testssl.sh:latest");
        assert_eq!(plugin.manifest.docker.network, "bridge");
        assert!(
            plugin
                .manifest
                .fixed_args
                .contains(&"--jsonfile-pretty".to_string())
        );
        assert!(
            plugin
                .manifest
                .fixed_args
                .contains(&"/artifacts/result.json".to_string())
        );
    }

    #[test]
    fn scans_network_plugin_manifests() {
        let plugins = scan_plugins(Path::new("plugins")).unwrap();

        let nmap = plugins.get("nmap").unwrap();
        assert_eq!(nmap.manifest.container, "instrumentisto/nmap:7.98-r2");
        assert!(
            nmap.manifest
                .docker
                .cap_add
                .iter()
                .any(|cap| cap == "NET_RAW")
        );

        let naabu = plugins.get("naabu").unwrap();
        assert_eq!(naabu.manifest.container, "projectdiscovery/naabu:v2.6.1");
        assert!(naabu.manifest.docker.cap_add.iter().any(|cap| cap == "NET_RAW"));
        assert!(naabu.manifest.options.iter().any(|option| option.name == "scan_type"));

        let rawping = plugins.get("rawping").unwrap();
        assert_eq!(rawping.manifest.docker.cap_add, vec!["NET_RAW"]);

        let nuclei = plugins.get("nuclei").unwrap();
        assert_eq!(nuclei.manifest.container, "slickchook-plugin/nuclei:local");
        assert!(nuclei.manifest.docker.cap_add.is_empty());

        let httpx = plugins.get("httpx").unwrap();
        assert_eq!(httpx.manifest.container, "projectdiscovery/httpx:v1.9.0");
        assert!(httpx.manifest.docker.cap_add.is_empty());

        for name in ["medusa", "feroxbuster", "waymore", "subfinder"] {
            let plugin = plugins.get(name).unwrap();
            assert!(plugin.manifest.docker.cap_add.is_empty());
        }
        assert_eq!(
            plugins.get("subfinder").unwrap().manifest.container,
            "projectdiscovery/subfinder:v2.14.0"
        );
    }

    #[test]
    fn allows_only_net_raw_capability() {
        let mut policy = DockerPolicy::default();
        policy.cap_add = vec!["NET_RAW".to_string()];
        validate_docker_policy(&policy).unwrap();

        policy.cap_add = vec!["NET_ADMIN".to_string()];
        let error = validate_docker_policy(&policy).unwrap_err();
        assert!(error.to_string().contains("NET_RAW"));
    }
}
