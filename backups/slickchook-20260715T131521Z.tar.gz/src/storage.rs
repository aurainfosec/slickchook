use anyhow::{Result, bail};
use std::path::Path;
use rusqlite::{Connection, params};

pub trait RunStore: Send + Sync {
    fn resolve_completed_input(&self, run_id: &str) -> Result<std::path::PathBuf>;
    fn record_run(&self, run: &StoredRun<'_>) -> Result<()>;
}

pub struct StoredRun<'a> {
    pub run_id: &'a str,
    pub plugin: &'a str,
    pub status: &'a str,
    pub artifact_dir: &'a Path,
    pub stdout_path: &'a Path,
    pub stderr_path: &'a Path,
    pub input_json: &'a str,
}

pub struct SqliteStore {
    pub db_path: std::path::PathBuf,
    pub artifacts_root: std::path::PathBuf,
}

impl RunStore for SqliteStore {
    fn resolve_completed_input(&self, run_id: &str) -> Result<std::path::PathBuf> {
        let conn = Connection::open(&self.db_path)?;
        let dir: String = conn.query_row(
            "SELECT artifact_dir FROM plugin_runs WHERE run_id = ?1 AND status IN ('success','failed')",
            params![run_id], |row| row.get(0))?;
        let root = std::fs::canonicalize(&self.artifacts_root)?;
        let run = std::fs::canonicalize(dir)?;
        if !run.starts_with(&root) { bail!("run artifact is outside artifact root"); }
        let input = std::fs::canonicalize(run.join("input"))?;
        if !input.starts_with(&run) { bail!("input directory is outside run artifact"); }
        Ok(input)
    }

    fn record_run(&self, run: &StoredRun<'_>) -> Result<()> {
        let conn = Connection::open(&self.db_path)?;
        conn.execute("INSERT OR REPLACE INTO plugin_runs (run_id, plugin, status, input_json, artifact_dir, stdout_artifact, stderr_artifact) VALUES (?1,?2,?3,?4,?5,?6,?7)", params![run.run_id, run.plugin, run.status, run.input_json, run.artifact_dir.to_string_lossy(), run.stdout_path.to_string_lossy(), run.stderr_path.to_string_lossy()])?;
        Ok(())
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum StorageBackend {
    Sqlite,
    Postgres,
}

impl StorageBackend {
    pub fn from_env() -> Result<Self> {
        match std::env::var("SLICKCHOOK_STORAGE_BACKEND")
            .unwrap_or_else(|_| "sqlite".to_string())
            .to_ascii_lowercase()
            .as_str()
        {
            "sqlite" => Ok(Self::Sqlite),
            "postgres" | "postgresql" => Ok(Self::Postgres),
            value => bail!("unsupported storage backend `{value}`; use sqlite or postgres"),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::StorageBackend;

    #[test]
    fn defaults_to_sqlite_without_configuration() {
        // The production default remains SQLite; backend activation is explicit.
        assert_eq!(StorageBackend::Sqlite, StorageBackend::Sqlite);
    }
}
